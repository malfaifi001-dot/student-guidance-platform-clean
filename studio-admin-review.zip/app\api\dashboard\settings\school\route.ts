import { NextResponse } from "next/server";
import { requireActiveSubscriptionForCurrentUser } from "@/bin/require-auth";
import { getCurrentSessionUser } from "@/lib/auth/current-user";
import { prisma } from "@/lib/prisma";
import { schoolSettingsPatchSchema } from "@/lib/settings/school-settings-api-schema";

export async function GET() {
  const current = await getCurrentSessionUser();

  if (!current) {
    return NextResponse.json(
      { success: false, error: "يلزم تسجيل الدخول." },
      { status: 401 },
    );
  }

  const profile = current.user.schoolAccount?.profile;

  return NextResponse.json({
    success: true,
    data: {
      officialName: current.user.officialName || current.user.name || "",
      jobTitle: current.user.jobTitle || "",
      phone: current.user.phone || "",
      schoolName: profile?.schoolName || "",
      principalName: profile?.principalName || "",
      principalPhone: profile?.principalPhone || "",
      principalSignatureUrl: profile?.principalSignatureUrl || "",
      principalSignatureRequestedAt:
        profile?.principalSignatureRequestedAt?.toISOString() || "",
      principalSignatureSignedAt:
        profile?.principalSignatureSignedAt?.toISOString() || "",
      activityLeaderName: profile?.activityLeaderName || "",
      activityLeaderSignatureUrl: profile?.activityLeaderSignatureUrl || "",
      activityLeaderSignedAt:
        profile?.activityLeaderSignedAt?.toISOString() || "",
      counselorSignatureUrl: profile?.counselorSignatureUrl || "",
      counselorSignedAt: profile?.counselorSignedAt?.toISOString() || "",
      educationDepartment: profile?.educationDepartment || "",
      educationOffice: profile?.educationOffice || "",
      city: profile?.city || "",
      district: profile?.district || "",
      stage: profile?.stage || "",
      academicYear: profile?.academicYear || "",
      currentSemester: profile?.currentSemester || "",
      logoUrl: profile?.logoUrl || "",
      onboardingCompleted: current.user.onboardingCompleted,
    },
  });
}

export async function PATCH(request: Request) {
  try {
    const subscriptionGuard = await requireActiveSubscriptionForCurrentUser();

    if (subscriptionGuard instanceof Response) {
      return subscriptionGuard;
    }

    const current = await getCurrentSessionUser();

    if (!current || !current.user.schoolAccountId) {
      return NextResponse.json(
        { success: false, error: "يلزم تسجيل الدخول." },
        { status: 401 },
      );
    }

    const body = await request.json().catch(() => null);
    const payloadResult = schoolSettingsPatchSchema.safeParse(body);

    if (!payloadResult.success) {
      return NextResponse.json(
        {
          success: false,
          error:
            payloadResult.error.issues[0]?.message ||
            "بيانات المدرسة غير صالحة.",
        },
        { status: 400 },
      );
    }

    const {
      officialName,
      jobTitle,
      phone,
      schoolName,
      principalName,
      principalPhone,
      activityLeaderName,
      educationDepartment,
      educationOffice,
      city,
      district,
      stage,
      academicYear,
      currentSemester,
      logoUrl,
    } = payloadResult.data;

    await prisma.$transaction([
      prisma.user.update({
        where: {
          id: current.user.id,
        },
        data: {
          officialName,
          jobTitle,
          phone,
          onboardingCompleted: true,
          onboardingCompletedAt: new Date(),
        },
      }),
      prisma.schoolAccount.update({
        where: {
          id: current.user.schoolAccountId,
        },
        data: {
          name: officialName || schoolName,
        },
      }),
      prisma.schoolProfile.upsert({
        where: {
          schoolAccountId: current.user.schoolAccountId,
        },
        update: {
          schoolName,
          principalName,
          principalPhone,
          activityLeaderName,
          educationDepartment,
          educationOffice,
          city,
          district,
          stage,
          academicYear,
          currentSemester,
          logoUrl,
        },
        create: {
          schoolAccountId: current.user.schoolAccountId,
          schoolName,
          principalName,
          principalPhone,
          activityLeaderName,
          educationDepartment,
          educationOffice,
          city,
          district,
          stage,
          academicYear,
          currentSemester,
          logoUrl,
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      message: "تم حفظ بيانات المدرسة والحساب.",
    });
  } catch (error) {
    console.error("SCHOOL_SETTINGS_SAVE_ERROR", error);

    return NextResponse.json(
      { success: false, error: "حدث خطأ أثناء حفظ إعدادات المدرسة." },
      { status: 500 },
    );
  }
}
