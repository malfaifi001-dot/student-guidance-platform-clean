import type { CertificateSignatureProfile } from "@/lib/certificates/certificate-signature-profile";

export type CertificateRenderRecord = {
  id: string;
  schoolAccountId: string;
  certificateNumber: string;
  certificateType: string;
  recipientType: string;
  recipientName: string;
  title: string;
  reason: string | null;
  body: string | null;
  issueDate: Date | string;
  dataJson?: unknown;
};

export type CertificateRenderOptions = {
  baseUrl?: string;
  signatureProfile?: CertificateSignatureProfile | null;
};

export function readCertificateDataJson(value: unknown): Record<string, unknown> {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }

  try {
    const parsed = JSON.parse(String(value));

    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    return {};
  }

  return {};
}

function escapeHtml(value: unknown) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function clean(value: unknown) {
  return String(value ?? "").trim();
}

function resolveUrl(url: unknown, baseUrl?: string) {
  const raw = clean(url);

  if (!raw) return "";
  if (/^(https?:|data:|blob:)/i.test(raw)) return raw;

  if (baseUrl && raw.startsWith("/uploads/")) {
    try {
      return new URL(raw, baseUrl).toString();
    } catch {
      return raw;
    }
  }

  return raw;
}

export function formatCertificateDate(value: Date | string) {
  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return date.toLocaleDateString("ar-SA-u-ca-gregory", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
}

function renderSignatureBox(input: {
  title: string;
  name: string;
  signatureUrl?: string;
  baseUrl?: string;
}) {
  const signatureUrl = resolveUrl(input.signatureUrl, input.baseUrl);

  return `
    <div class="signature-box">
      <div class="signature-title">${escapeHtml(input.title)}</div>
      <div class="signature-image-wrap">
        ${
          signatureUrl
            ? `<img src="${escapeHtml(signatureUrl)}" alt="${escapeHtml(input.title)}" />`
            : `<div class="signature-line"></div>`
        }
      </div>
      <div class="signature-name">${escapeHtml(input.name || "........................")}</div>
    </div>
  `;
}

export function renderCertificateDocumentHtml(
  certificate: CertificateRenderRecord,
  options: CertificateRenderOptions = {},
) {
  const data = readCertificateDataJson(certificate.dataJson);
  const profile = options.signatureProfile;

  const principalName =
    clean(data.principalName) || profile?.principalName || "مدير المدرسة";
  const principalSignatureUrl =
    clean(data.principalSignatureUrl) || profile?.principalSignatureUrl || "";

  const issuerTitle =
    clean(data.issuerTitle) || profile?.issuerTitle || "الموجه الطلابي";
  const issuerName =
    clean(data.issuerName) || profile?.issuerName || "الموجه الطلابي";
  const issuerSignatureUrl =
    clean(data.issuerSignatureUrl) ||
    profile?.issuerSignatureUrl ||
    "";

  const ministryLogoUrl = resolveUrl("/uploads/school-logos/MOE.png", options.baseUrl);
  const visionLogoUrl = resolveUrl("/uploads/school-logos/VISION2030.png", options.baseUrl);

  return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(certificate.title || "شهادة")}</title>
  <style>
    @page { size: A4 landscape; margin: 0; }

    * { box-sizing: border-box; }

    html,
    body {
      margin: 0;
      padding: 0;
      background: #e5e7eb;
      direction: rtl;
      font-family: Arial, Tahoma, sans-serif;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    .certificate-shell {
      width: 297mm;
      height: 210mm;
      margin: 0 auto;
      background: #fbfdf9;
      position: relative;
      overflow: hidden;
      color: #0f172a;
    }

    .top {
      position: absolute;
      inset-inline: 0;
      top: 0;
      height: 38mm;
      background: #0f7a57;
      border-bottom-left-radius: 45%;
      border-bottom-right-radius: 45%;
    }

    .bottom {
      position: absolute;
      inset-inline: 0;
      bottom: 0;
      height: 33mm;
      background: #0f7a57;
      border-top-left-radius: 45%;
      border-top-right-radius: 45%;
    }

    .gold-top {
      position: absolute;
      inset-inline: 0;
      top: 31mm;
      height: 8mm;
      background: #d6b15f;
      opacity: .9;
      border-bottom-left-radius: 60%;
      border-bottom-right-radius: 60%;
    }

    .gold-bottom {
      position: absolute;
      inset-inline: 0;
      bottom: 29mm;
      height: 8mm;
      background: #d6b15f;
      opacity: .9;
      border-top-left-radius: 60%;
      border-top-right-radius: 60%;
    }

    .outer {
      position: absolute;
      inset: 15mm;
      border: 1.3mm solid #d6b15f;
      border-radius: 9mm;
    }

    .inner {
      position: absolute;
      inset: 21mm;
      border: .45mm solid rgba(15, 122, 87, .35);
      border-radius: 7mm;
    }

    .logo {
      position: absolute;
      top: 23mm;
      width: 48mm;
      height: 19mm;
      border-radius: 5mm;
      background: rgba(255,255,255,.94);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #0f7a57;
      font-weight: 900;
      font-size: 11px;
      overflow: hidden;
      padding: 2mm;
    }

    .logo img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
      display: block;
    }

    .vision { left: 26mm; }
    .moe { right: 26mm; }

    .medal {
      position: absolute;
      top: 39mm;
      left: 50%;
      width: 23mm;
      height: 23mm;
      transform: translateX(-50%);
      border: 1.4mm solid #d6b15f;
      border-radius: 999px;
      background: #f7f0d7;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #0f7a57;
      font-size: 28px;
      font-weight: 900;
    }

    .content {
      position: absolute;
      top: 70mm;
      left: 32mm;
      right: 32mm;
      text-align: center;
    }

    .title {
      color: #0f7a57;
      font-size: 36px;
      line-height: 1.2;
      font-weight: 900;
      margin: 0;
    }

    .line {
      width: 95mm;
      height: 1.2mm;
      background: #d6b15f;
      border-radius: 99px;
      margin: 8mm auto 0;
    }

    .intro {
      margin: 10mm 0 0;
      color: #374151;
      font-size: 18px;
      font-weight: 700;
    }

    .name {
      margin: 8mm 0 0;
      color: #111827;
      font-size: 34px;
      font-weight: 900;
      line-height: 1.25;
    }

    .body {
      margin: 8mm auto 0;
      max-width: 205mm;
      color: #374151;
      font-size: 18px;
      line-height: 1.9;
      font-weight: 700;
    }

    .reason {
      margin: 4mm auto 0;
      color: #64748b;
      font-size: 13px;
      line-height: 1.7;
      font-weight: 800;
    }

    .signatures {
      position: absolute;
      left: 26mm;
      right: 26mm;
      bottom: 24mm;
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 20mm;
    }

    .signature-box {
      width: 62mm;
      text-align: center;
      color: #374151;
      font-size: 12px;
      font-weight: 900;
    }

    .signature-title {
      margin-bottom: 2mm;
    }

    .signature-image-wrap {
      height: 17mm;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 2mm;
    }

    .signature-image-wrap img {
      max-width: 58mm;
      max-height: 17mm;
      object-fit: contain;
      display: block;
    }

    .signature-line {
      width: 100%;
      height: .6mm;
      background: #0f7a57;
      margin-top: 12mm;
    }

    .signature-name {
      color: #64748b;
      font-size: 11px;
      font-weight: 800;
      min-height: 5mm;
    }

    .meta {
      position: absolute;
      left: 50%;
      bottom: 28mm;
      transform: translateX(-50%);
      text-align: center;
      color: #64748b;
      font-size: 11px;
      line-height: 1.7;
      font-weight: 800;
    }

    @media print {
      html, body { background: white; }
      .certificate-shell { margin: 0; box-shadow: none; }
    }
  </style>
</head>
<body>
  <section class="certificate-shell">
    <div class="top"></div>
    <div class="gold-top"></div>
    <div class="bottom"></div>
    <div class="gold-bottom"></div>
    <div class="outer"></div>
    <div class="inner"></div>

    <div class="logo vision"><img src="${escapeHtml(visionLogoUrl)}" alt="رؤية 2030" /></div>
    <div class="logo moe"><img src="${escapeHtml(ministryLogoUrl)}" alt="وزارة التعليم" /></div>
    <div class="medal">✓</div>

    <main class="content">
      <h1 class="title">${escapeHtml(certificate.title || "شهادة")}</h1>
      <div class="line"></div>
      <p class="intro">تتقدم إدارة المدرسة بخالص الشكر والتقدير إلى</p>
      <div class="name">${escapeHtml(certificate.recipientName)}</div>
      <p class="body">${escapeHtml(certificate.body || "")}</p>
      ${certificate.reason ? `<p class="reason">سبب التكريم: ${escapeHtml(certificate.reason)}</p>` : ""}
    </main>

    <div class="signatures">
      ${renderSignatureBox({
        title: issuerTitle,
        name: issuerName,
        signatureUrl: issuerSignatureUrl,
        baseUrl: options.baseUrl,
      })}

      ${renderSignatureBox({
        title: "مدير المدرسة",
        name: principalName,
        signatureUrl: principalSignatureUrl,
        baseUrl: options.baseUrl,
      })}
    </div>

    <div class="meta">
      <div>تاريخ الإصدار: ${escapeHtml(formatCertificateDate(certificate.issueDate))}</div>
      <div>رقم الشهادة: ${escapeHtml(certificate.certificateNumber)}</div>
    </div>
  </section>
</body>
</html>`;
}
